﻿using System.Collections.Generic;
using System;
using System.Xml.Serialization;
using System.Reflection.Emit;

namespace GeneratorDataProcessor.Models
{
    [XmlRoot("GenerationOutput")]
    public class GenerationOutput
    {
        [XmlElement("Totals")]
        public Totals Totals { get; set; } = new Totals();

        [XmlElement("MaxEmissionGenerators")]
        public MaxEmissionGenerators MaxEmissionGenerators { get; set; } = new MaxEmissionGenerators();

        [XmlElement("ActualHeatRates")]
        public ActualHeatRates ActualHeatRates { get; set; } = new ActualHeatRates();
    }

    public class Totals
    {
        [XmlElement("Generator")]
        public List<GeneratorTotal> Generator { get; set; } = new List<GeneratorTotal>();
    }

    public class GeneratorTotal
    {
        [XmlElement("Name")]
        public string Name { get; set; } = string.Empty;

        [XmlElement("Total")]
        public decimal Total { get; set; }
    }

    public class MaxEmissionGenerators
    {
        [XmlElement("Day")]
        public List<DayEmission> Day { get; set; } = new List<DayEmission>();
    }

    public class DayEmission
    {
        [XmlElement("Name")]
        public string Name { get; set; } = string.Empty;

        [XmlElement("Date")]
        public DateTime Date { get; set; }

        [XmlElement("Emission")]
        public decimal Emission { get; set; }
    }

    public class ActualHeatRates
    {
        [XmlElement("ActualHeatRate")]
        public List<ActualHeatRate> ActualHeatRate { get; set; } = new List<ActualHeatRate>();
    }

    public class ActualHeatRate
    {
        [XmlElement("Name")]
        public string Name { get; set; } = string.Empty;

        [XmlElement("HeatRate")]
        public decimal HeatRate { get; set; }
    }
}