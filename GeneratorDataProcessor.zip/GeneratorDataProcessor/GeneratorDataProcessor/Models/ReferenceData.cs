﻿using System.Collections.Generic;

namespace GeneratorDataProcessor.Models
{
    public class ReferenceData
    {
        public Dictionary<string, decimal> ValueFactors { get; set; } = new Dictionary<string, decimal>();
        public Dictionary<string, decimal> EmissionFactors { get; set; } = new Dictionary<string, decimal>();
    }
}