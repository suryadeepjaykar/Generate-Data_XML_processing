﻿using GeneratorDataProcessor.Services;
using System;

namespace GeneratorDataProcessor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var processor = new GeneratorProcessor();
                processor.StartProcessing();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Application Error: {ex.Message}");
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            }
        }
    }
}
