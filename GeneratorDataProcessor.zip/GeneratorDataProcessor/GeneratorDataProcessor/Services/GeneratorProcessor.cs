﻿using System.Collections.Generic;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading;
using System.Xml.Linq;
using System.Xml.Serialization;
using GeneratorDataProcessor.Models;

namespace GeneratorDataProcessor.Services
{
    public class GeneratorProcessor
    {
        private readonly string inputFolder;
        private readonly string outputFolder;
        private readonly string referenceDataPath;
        private readonly FileSystemWatcher watcher;
        private ReferenceData referenceData;

        public GeneratorProcessor()
        {
            inputFolder = ConfigurationManager.AppSettings["InputFolder"] ?? "C:\\Generator\\Input";
            outputFolder = ConfigurationManager.AppSettings["OutputFolder"] ?? "C:\\Generator\\Output";
            referenceDataPath = ConfigurationManager.AppSettings["ReferenceDataFile"] ?? "ReferenceData.xml";

            Directory.CreateDirectory(inputFolder);
            Directory.CreateDirectory(outputFolder);

            LoadReferenceData();

            watcher = new FileSystemWatcher(inputFolder, "*.xml");
            watcher.Created += OnFileCreated;
        }

        private void LoadReferenceData()
        {
            try
            {
                string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, referenceDataPath);
                var doc = XDocument.Load(fullPath);
                referenceData = new ReferenceData
                {
                    ValueFactors = new Dictionary<string, decimal>
                    {
                        ["High"] = decimal.Parse(doc.Descendants("ValueFactor").Descendants("High").First().Value),
                        ["Medium"] = decimal.Parse(doc.Descendants("ValueFactor").Descendants("Medium").First().Value),
                        ["Low"] = decimal.Parse(doc.Descendants("ValueFactor").Descendants("Low").First().Value)
                    },
                    EmissionFactors = new Dictionary<string, decimal>
                    {
                        ["High"] = decimal.Parse(doc.Descendants("EmissionsFactor").Descendants("High").First().Value),
                        ["Medium"] = decimal.Parse(doc.Descendants("EmissionsFactor").Descendants("Medium").First().Value),
                        ["Low"] = decimal.Parse(doc.Descendants("EmissionsFactor").Descendants("Low").First().Value)
                    }
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading reference data: {ex.Message}");
                throw;
            }
        }

        public void StartProcessing()
        {
            try
            {
                watcher.EnableRaisingEvents = true;
                Console.WriteLine($"Monitoring folder: {inputFolder}");
                Console.WriteLine("Press Enter to exit...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error starting file monitoring: {ex.Message}");
                throw;
            }
        }

        private void OnFileCreated(object sender, FileSystemEventArgs e)
        {
            try
            {
                Thread.Sleep(100); // Wait for file to be ready
                ProcessFile(e.FullPath);
                Console.WriteLine($"Processed file: {e.Name}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing file {e.Name}: {ex.Message}");
            }
        }

        private void ProcessFile(string filePath)
        {
            var doc = XDocument.Load(filePath);
            var output = new GenerationOutput();

            ProcessWindGenerators(doc, output.Totals.Generator);
            ProcessGasGenerators(doc, output.Totals.Generator);
            ProcessCoalGenerators(doc, output.Totals.Generator, output.ActualHeatRates.ActualHeatRate);

            CalculateMaxEmissionsPerDay(doc, output.MaxEmissionGenerators.Day);

            string outputPath = Path.Combine(outputFolder,
                Path.GetFileNameWithoutExtension(filePath) + "-Result.xml");
            SaveOutput(output, outputPath);
        }

        private void ProcessWindGenerators(XDocument doc, List<GeneratorTotal> totals)
        {
            foreach (var generator in doc.Descendants("WindGenerator"))
            {
                var name = generator.Element("Name")?.Value;
                var location = generator.Element("Location")?.Value;
                var valueFactor = location == "Offshore" ?
                    referenceData.ValueFactors["Low"] :
                    referenceData.ValueFactors["High"];

                decimal total = 0;
                foreach (var day in generator.Descendants("Day"))
                {
                    var energy = decimal.Parse(day.Element("Energy")?.Value ?? "0");
                    var price = decimal.Parse(day.Element("Price")?.Value ?? "0");
                    total += energy * price * valueFactor;
                }

                totals.Add(new GeneratorTotal { Name = name ?? "", Total = total });
            }
        }

        private void ProcessGasGenerators(XDocument doc, List<GeneratorTotal> totals)
        {
            foreach (var generator in doc.Descendants("GasGenerator"))
            {
                ProcessFossilFuelGenerator(generator, "Medium", totals);
            }
        }

        private void ProcessCoalGenerators(XDocument doc, List<GeneratorTotal> totals,
            List<ActualHeatRate> heatRates)
        {
            foreach (var generator in doc.Descendants("CoalGenerator"))
            {
                ProcessFossilFuelGenerator(generator, "Medium", totals);

                var totalHeatInput = decimal.Parse(generator.Element("TotalHeatInput")?.Value ?? "0");
                var actualNetGeneration = decimal.Parse(generator.Element("ActualNetGeneration")?.Value ?? "0");

                heatRates.Add(new ActualHeatRate
                {
                    Name = generator.Element("Name")?.Value ?? "",
                    HeatRate = actualNetGeneration != 0 ? totalHeatInput / actualNetGeneration : 0
                });
            }
        }

        private void ProcessFossilFuelGenerator(XElement generator, string valueFactor,
            List<GeneratorTotal> totals)
        {
            var name = generator.Element("Name")?.Value ?? "";
            decimal total = 0;

            foreach (var day in generator.Descendants("Day"))
            {
                var energy = decimal.Parse(day.Element("Energy")?.Value ?? "0");
                var price = decimal.Parse(day.Element("Price")?.Value ?? "0");
                total += energy * price * referenceData.ValueFactors[valueFactor];
            }

            totals.Add(new GeneratorTotal { Name = name, Total = total });
        }

        private void CalculateMaxEmissionsPerDay(XDocument doc, List<DayEmission> maxEmissions)
        {
            var dates = doc.Descendants("Day")
                .Select(d => DateTime.Parse(d.Element("Date")?.Value ?? DateTime.MinValue.ToString()))
                .Distinct();

            foreach (var date in dates)
            {
                var maxEmission = new DayEmission { Date = date };

                foreach (var generator in doc.Descendants("GasGenerator")
                    .Concat(doc.Descendants("CoalGenerator")))
                {
                    var dayData = generator.Descendants("Day")
                        .FirstOrDefault(d => DateTime.Parse(d.Element("Date")?.Value ?? "") == date);

                    if (dayData != null)
                    {
                        var energy = decimal.Parse(dayData.Element("Energy")?.Value ?? "0");
                        var emissionsRating = decimal.Parse(generator.Element("EmissionsRating")?.Value ?? "0");
                        var emissionFactor = generator.Name.LocalName == "GasGenerator" ?
                            referenceData.EmissionFactors["Medium"] :
                            referenceData.EmissionFactors["High"];

                        var emission = energy * emissionsRating * emissionFactor;

                        if (emission > maxEmission.Emission)
                        {
                            maxEmission.Emission = emission;
                            maxEmission.Name = generator.Element("Name")?.Value ?? "";
                        }
                    }
                }

                if (maxEmission.Emission > 0)
                {
                    maxEmissions.Add(maxEmission);
                }
            }
        }

        private void SaveOutput(GenerationOutput output, string path)
        {
            var serializer = new XmlSerializer(typeof(GenerationOutput));
            var writer = new StreamWriter(path);
            serializer.Serialize(writer, output);
        }
    }
}